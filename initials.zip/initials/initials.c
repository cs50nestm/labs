#include <cs50.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
  
}
