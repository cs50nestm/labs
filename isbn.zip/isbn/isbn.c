#include <cs50.h>
#include <stdio.h>

int main(void)
{


}
